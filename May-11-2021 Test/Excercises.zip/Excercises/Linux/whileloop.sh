cat file1.txt | while read line 
do
	echo $line

done
